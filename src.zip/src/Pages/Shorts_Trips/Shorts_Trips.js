import React, { useEffect } from "react";
import "./Shorts_Trips.css";

export default function Shorts_Trips() {
  useEffect(() => {
    document.title = `Dimaniyat Tours | Shorts Trips`;
  });

  return (
    <>
      <div className="Shorts_Trips">
        <h1>Shorts_Trips</h1>
        https://www.lightgalleryjs.com/docs/react/ LINK Type
      </div>
    </>
  );
}
