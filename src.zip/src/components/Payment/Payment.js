/* eslint-disable jsx-a11y/iframe-has-title */
/* eslint-disable jsx-a11y/iframe-has-title */
import React, { useState } from "react";
import "./Payment.css";

const PayNow = (props) => {
  return (
    <>
      <h1>PAYPAL HERE</h1>
    </>
  );
};

export default PayNow;
