import React from "react";


export default function Receipt() {
  
  return (
    <>
      <h1>Receipt Cancel</h1>
    </>
  );
}
